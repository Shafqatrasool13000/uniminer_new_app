import styled from 'styled-components';
export const RevenueRateMain=styled.div`
margin-top:1.6rem;
`